export const booleanDataAttr = (condition: boolean | undefined) =>
  condition ? '' : undefined;

export const booleanAriaAttr = (condition: boolean | undefined) =>
  condition ? true : undefined;
