import { createEvent } from 'effector';

export const appStarted = createEvent();
